NoSSL
=====

NoSSL is an open-source software to encrypt the data sent between browser and webserver to protect it from 
hackers, internet service providers and spies (more info under http://www.NoSSL.net).
It does not protect against the man-in-the-middle attack.

FOR PRIVATE USE IT IS LICENSED UNDER THE GPL V3.
<br />FOR COMMERCIAL USE, please inquire through www.nossl.net or www.smartinmedia.com

INSTALLATION: please go to <a href="http://www.nossl.net">www.NoSSL.net</a> and read the page "Getting started"!
