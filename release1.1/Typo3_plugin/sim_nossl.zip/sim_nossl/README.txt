The standard setup for NoSSL should be used, if you do not want to care about which of the forms have to be encrypted. In the standard setup, a) all the forms will be encrypted automatically before sending to the server and b) all AJAX-communication from client to server will be encrypted.
You can exclude some of the forms of encryption (and also AJAX-calls), which will be explained below.
To implement NoSSL into your website, please follow these simple steps:

1. Download NoSSL, unzip. Copy the NoSSL directory into your public HTML folder (document root).
2. Include the PHP library of NoSSL by including nossl_start.php into your PHP script, which will ultimately present the form(s). Including (or better: “require_once”) has to be the first command in your PHP scripts.

require_once('./nossl/nossl_start.php');

3. Include the NoSSL JavaScript library by first loading jquery.js, then nossl_standard.min.js in your HTML code. Also, include the important CSS of NoSSL as it hides submit-buttons as long as JavaScript is not executed to prevent users from sending unencrypted data.

<link href="./nossl/style/nossl.css" type="text/css" rel="stylesheet" />
<script src="./nossl/javascript/jquery.js"></script>
<script src="./nossl/javascript/nossl_standard.min.js"></script>

Note:
Now, all your forms and all AJAX-data should be encrypted. However, due to limitations of HTML, NoSSL cannot encrypt file-uploads!
a) If you want to exclude forms from being automatically encrypted, add the CSS class “nossl_disable_protection” like this:

<form action="demo.php" class="nossl_disable_protection" method="post">
b) If you want to prevent your AJAX-data from being encrypted, just add an empty “beforeSend” to your AJAX-call:

$.ajax({
            beforeSend: function(){},
            type: "POST",
            url: "./demo.php",
            data: {nossl_ajaxtest: tester},
            async: false,
            dataType: "json",
            success: function(msg) {
                if (msg===null || msg.status === false){
                    console.log('Ajax Function error');
                }
                else {    
 
                    //YOUR CODE, IF EVERYTHING WENT FINE
                }},
            error: function() {
                console.log('An error ocurred (AJAX ERROR)!');
                }
});

c) If you want to use PHP to echo an encrypted string, just use

nossl_echo($string); //This will be echoed into the document as an encrypted text. The text will be hidden and only displayed in the browser once decrypted