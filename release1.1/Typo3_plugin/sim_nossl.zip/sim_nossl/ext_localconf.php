<?php
if (!defined('TYPO3_MODE')) {
    die ('Access denied.');
}

t3lib_extMgm::addPItoST43($_EXTKEY, 'pi1/class.tx_simnossl_pi1.php', '_pi1', 'includeLib', 0);
t3lib_extMgm::addStaticFile($_EXTKEY,'static/', 'Add TS');
t3lib_extMgm::addPageTSConfig(
    '<INCLUDE_TYPOSCRIPT: source="FILE:EXT:' . $_EXTKEY . '/static/setup.txt">'
);
// Hook for NoSSL base system
$TYPO3_CONF_VARS['SC_OPTIONS']['tslib/index_ts.php']['preprocessRequest'][$_EXTKEY] = 'EXT:' . $_EXTKEY . '/hooks/PreProcessRequest.php:Tx_Nossl_Hooks_PreprocessRequest->user_start';

// Route ajax calls to base system
$TYPO3_CONF_VARS['FE']['eID_include'][$_EXTKEY] = 'EXT:' . $_EXTKEY . '/nossl/nossl_start.php';
