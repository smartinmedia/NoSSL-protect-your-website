<?php
/***************************************************************
 *  Copyright notice
 *
 *  (c) 2014 Oliver Monneke <oliver@codersquad.de>
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

// NoSSL base script
require_once(t3lib_extMgm::extPath('sim_nossl') . 'nossl/nossl_start.php');

/**
 * Hook into index_ts.php to manipulate decode all GET, POST and REQUEST vars
 *
 * @author    Oliver Monneke <oliver@codersquad.de>
 * @package    TYPO3
 * @subpackage    tx_simnossl
 */
class Tx_Nossl_Hooks_PreprocessRequest
{

    /**
     * just a dummy, Typo3 needs to call a method
     */
    public function user_start()
    {
    }
}

if (defined('TYPO3_MODE') && $TYPO3_CONF_VARS[TYPO3_MODE]['XCLASS']['ext/sim_nossl/hooks/PreProcessRequest.php']) {
    require_once($TYPO3_CONF_VARS[TYPO3_MODE]['XCLASS']['ext/sim_nossl/hooks/PreProcessRequest.php']);
}