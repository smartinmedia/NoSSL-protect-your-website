<?php
//NoSSL Private RSA Key - PROTECT THIS FILE SO THAT NO ONE ACCESSES IT FROM OUTSIDE! Do not share this file with others, else the NoSSL security is hampered!

$nossl_rsa_privatekey = array('current_rsa_privatekey' => '-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEAtC/c30Ng3hHOKBYfjmRVjM95dSnQ7d8VML9MQSGVKqMJ9nKp
I1JUgcqUaYJLzobFFb6VSO7swnsu+UoI4r6/Jy6I71+D9jiLSAyB1ZdfclZENBuA
hZA/hHcYSvLdeHisO8dQqLPNZ30x3MNPiF8uYaJvL764StxgR3jUZRskmpbWwAkg
aYrhsDdUWGOrHbvQD41zVpoLviqeC1fMuNRtuhVqpAiNpnOcJqCbdB6g/7SqZSm2
fMmZR7Vc/DIbv8tfeyima+ALYu1PMi1q/8ROoN+eCcujooedBYg5RScYPUklbLQ3
LOp1zVbv9j6RpJU0NBQDZ7YNPYTbbaf9XHKyYwIDAQABAoIBAAgEaSt18AVxfV7D
PTw0sqnFQX45EhbDakn0+Quc1upCvtq8V1I/A4uS2++l4IGb9YD2LeZE2zv8BycI
aETOf+raYzVjZpe6BFh8VfqO9aw8smQvJRTMSkc2lVogXEJT/DXctHYNKgKEy4cr
GYrT0Vh+xbu2HLUYASCs+6ZUAtjt8hUW7fBs/QbsQ6BAtvSXCmDGUSdvzNkuh3c0
Jfadk+/PobmvwmPg9gdJ/YHdZztTfqWBpGlO1ari5Slbxghh94OdkHdVVEpwu1A+
uQY/B0ynIZRpG3GvO6H/S2bFsKzUpoWsqkhwbUqnRh7BYYJlTIjIepsuYcgpM/zS
PauiAGECgYEA4fAZ/37aT0nPmm72gyNHEivB6IobqC17jSw+k7JLnWqNMG85AfO+
/rVsj7y/g8FLvRGmhbOXqiP8vlKyIAtTcf7ORqrr1mZvVTknvHl8HeoV0m97Efzr
o3ZsA4u/3A7B4b8Y+nzSbT4sL9vh3jDasUuA9ZNU7UezYdzE/CryqeUCgYEAzClk
gNd4Qf2k9NzBJ4M8S20KO0gFNi21rmSTU3i0IlyQK1dyIPmysRXmBFrCZd8BKO/B
h523d5eOecR1JoiSoBcfXvj7nU2FjFK97rPtzhB5Lqv9ARKWPZPE/3aV/RoLXA4/
liNju7wRDCC6FoAfvbi6FkmVA0rjuPMEf3LYhqcCgYEAjTA3btvcnJOpcf5JeeV/
sjE5+ZDke5IAlVXCvRU7/2DoXg4C999TyWOiNahjnXgbVklDYGW8LwxSErUmrrOl
L6VlTe/ddJuKkx0mYbchAqiXfms/4xvEPN/x271m5aMrMWDzwQRjkvS5NCcZ3Hl3
EDf4nH23Ipgd1tfZGSPVhKkCgYBGtYdTgEzsPhbln5deQfud+/PxOC5l50rnTXoh
DMsGo5xjBnRGq3SSFI2HsI9njObv8KnMeHlUeC8mST5xzBdMTvXUhNNQVcsNIJMb
m0GffuEZowOLXY6fYRB3kfC8qkqI5X5sV3FxUd9tneAVbuaPZO0+TtnHPCbGpZRH
N9V6PQKBgHfm7qKb1IUFjdB4RzcsMit9zGC75W9UyTli11blat61P+2jTWHSNU5+
z/4gXZQtssaGrXKh8+zZCv+8/sx/qXGgW000jdaks3RQM3Y8qvH40s3eodyC6gAS
QSUABmHcSWtkCarHz5Hb3f3Pzqo30MSoZNQyb9ZYW/mYwzRvdKV6
-----END RSA PRIVATE KEY-----',

//The current_rsa_timestamp and the last_rsa_timestamp store the Unix-time time(), when the current/last private key was generated. This is important, when the private key is renewed every day or so. The last private key has to be stored here, so that the server still has the right key present for browsers, which dont have the changed key yet. Supports some kind of perfect forward secrecy
'current_rsa_timestamp' => 1410791771,

'last_rsa_privatekey' => '-----BEGIN RSA PRIVATE KEY-----
MIIEogIBAAKCAQEAwe2phOjI0HxNEqwMai/XTuN5XDeaBuNmpJwDA/XBVKVu95fV
X97Q1WuczjlnU2jQ5ucVhE6Mdcrvyq0MXxuBTkSyYAGt+VUPc8R5XY+WpvUGbKRG
zHJ0ZagUQUdnGTSg/fLJUEZTOF714/xA7u8as0Z2RVMX5zfUl3KnPI1mx6C885Kn
+C7N4AVQ9mvmpBmL/c52uKgwt5NiYTI1az6vWcm3JSr13voE+QWZLxiFMtlnk521
ZyRO2mshk4Zj92jtTSUu+m3mZY7Bb7uWBl/ViFfUWvQBJxHvzAtW/L9ed0ZPcslY
MLfolQoCElGwLoKAg7GDaYBUVo4Lk/383ffFuwIDAQABAoIBAAV35ifRSJhYaPP1
1gPIhZG76FgpWTaIgwRxQcSC0YjJgW+J4IJrjgf2mN1X0QoREpLwQTMR4/QOXOSi
LI8h/2ttlHoQkg9Nzrm8+I8i1WSv1BaMK1Loh0+2hZuxn76eNUvz5KlW0lHsm5Jq
MoqKQ356piseRLZIZL5AhWa3tgY6/YghY8653+NNgXZwbv5aYrbFzw7MTddzwZy5
/CoQxdQLYmLcF0ED0PGO4wvBA7Jsr72MVVHEPFDYU0pFhrIBTElpLwjlMktC6qRv
GkaDd0YuOXITLfLUGKpSRD/XG9NRbzGpNQhtSWLUZBTbrrvCt9i1p8p0ukcV8HFc
mgz82MECgYEA31aEt6hMR6ovI/GDoVmoaUBI78YkVjXBN3T0bf3/DJWSDdC5luyu
reesmK7N2DsOeVOulnV3hR3iG6O1xQYUBDHluxdm5nAJl4QbWfs6dsqqANMDvrwW
woP+nbWbfoYBaK9CNiti5prCy44BI/4gZSmAx9iJbBe403LJjjS04L0CgYEA3koW
Qk39UExcuBvq176dUSAUyeku/Fd8r9fLgifazVHm+nk5qrTqpzlEaoZg6o1Zl3+l
lK3bmWEEklJVeVP28rSIiKe0jKPl3qasmpKpjiqhsAa+YtUWZgUmaTGeYUTD/9L8
ySLuzMRIeNZbIeBj0tfEDqrvmiQ0l4it3UN1E9cCgYBptr05ZZs9rMuFevMwc4zo
zPn5LNPUTrt3cY+lZL3OChpJGcxPKRcB0BB9cPiUalfOjBKuu0lopB17scD/UoI0
/h1cspYNa2jO5ERCEk25HvLbUwaJyOQJDIt/wQ+qEuol0BdKJr04pHah/USC8e4J
lFyVu+RIWu4sgD/xZPddDQKBgAdx7crst8Y/uH9GGBh/vt8ftvKIR9WVzIxLKvrC
APcNfjH3a3IHOzC8n0j+FTLl5xFG6jHPnOJHOJL6BPjaUhQQ7d292DM5rhJF/NP0
g49KaD3wC+JdhrGGDKJLUiWp2vKvi13lOKBNFqxNaaH51P4T0fI30WyVN9m3bzNQ
9hPjAoGAT6LBEw/CEpYn+R0UL4YWOoXno3NJ3j3rinIh7nAQZxMnoAPqNj/w5bAD
1dAEk3u6ZXAmIGs+7HfSKDsg+S04/XcusjWLxYzx85CAXrLRRMI4euPoyhqcRSSz
wAcZMwBY29AnXQ1GGxmZxRpIe8khYmiv6uZIrQNnfgvAGf3cG78=
-----END RSA PRIVATE KEY-----',

'last_rsa_timestamp' => 1410791465);

?>