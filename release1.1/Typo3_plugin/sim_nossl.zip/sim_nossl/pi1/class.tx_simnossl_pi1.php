<?php
/***************************************************************
 *  Copyright notice
 *
 *  (c) 2014 Oliver Monneke <oliver@codersquad.de>
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Plugin 'NoSSL' for the 'sim_nossl' extension.
 *
 * @author    Oliver Monneke <oliver@codersquad.de>
 * @package    TYPO3
 * @subpackage    tx_simnossl
 */
class tx_simnossl_pi1 extends tslib_pibase
{
    /**
     * @var string
     */
    public $prefixId = 'tx_simnossl_pi1'; // Same as class name

    /**
     * @var string
     */
    public $scriptRelPath = 'pi1/class.tx_simnossl_pi1.php'; // Path to this script relative to the extension dir.

    /**
     * @var string
     */
    public $extKey = 'sim_nossl'; // The extension key.

    /**
     * @var array
     */
    private static $_cssFiles = array(
        'nossl/style/nossl.css'
    );

    /**
     * The main method of the Plugin.
     *
     * @param string $content The Plugin content
     * @param array $conf The Plugin configuration
     * @return string The content that is displayed on the website
     */
    public function main($content, array $conf)
    {
        // Get extension configuration
        $confArray = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf'][$this->extKey]);

        $scripts = '';

        // Include CSS files
        foreach (self::$_cssFiles as $_file) {
            $scripts .= '<link href="' . t3lib_extMgm::siteRelPath($this->extKey) . $_file . '" type="text/css" rel="stylesheet" />';
        }

        // Include jQuery if configured
        if ($confArray['includeJquery'] === 1) {
            $scripts .= '<script src="' . t3lib_extMgm::siteRelPath($this->extKey) . 'nossl/javascript/jquery.js"></script>';
        }

        // Put all files into header
        $GLOBALS['TSFE']->additionalHeaderData[$this->prefixId] = $scripts;
    }
}


if (defined('TYPO3_MODE') && isset($GLOBALS['TYPO3_CONF_VARS'][TYPO3_MODE]['XCLASS']['ext/sim_nossl/pi1/class.tx_simnossl_pi1.php'])) {
    include_once($GLOBALS['TYPO3_CONF_VARS'][TYPO3_MODE]['XCLASS']['ext/sim_nossl/pi1/class.tx_simnossl_pi1.php']);
}