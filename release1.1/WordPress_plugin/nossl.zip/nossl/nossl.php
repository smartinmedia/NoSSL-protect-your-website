<?php

defined('ABSPATH') or die("No script kiddies please!");

/**
 * @package NoSSL
 * @version 1.0
 *
 */
/*
Plugin Name: NoSSL
Plugin URI: http://www.nossl.net/
Description: NoSSL is an open-source software to encrypt the data sent between browser and webserver to protect it from hackers, internet service providers and spies. It is a simple-to-implement library written in PHP and JavaScript, which you can easily integrate into your website. It will protect your login forms, contact forms and posts.
Author: Oliver Monneke
Version: 1.0
Author URI: http://www.nossl.net/
License: GPL3
*/

add_action('init', 'process_nossl');
add_action('wp_enqueue_scripts', 'add_meta_files');

/**
 *
 */
function process_nossl()
{
    require_once(__DIR__ . '/nossl/nossl_start.php');
}

/**
 *
 */
function add_meta_files()
{
    wp_enqueue_style('nossl-style', plugins_url('/nossl/style/nossl.css', __FILE__), array(), '1.0');
    wp_enqueue_script('nossl-js', plugins_url('/nossl/javascript/nossl_start.min.js', __FILE__), array(), '1.0');
}
