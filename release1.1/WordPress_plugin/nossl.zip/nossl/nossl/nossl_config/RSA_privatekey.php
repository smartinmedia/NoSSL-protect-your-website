<?php
//NoSSL Private RSA Key - PROTECT THIS FILE SO THAT NO ONE ACCESSES IT FROM OUTSIDE! Do not share this file with others, else the NoSSL security is hampered!

$nossl_rsa_privatekey = array('current_rsa_privatekey' => '-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEAqYOPI+UFRUjThiXSZBuxygcCjwt+dRBtRPQAwOVGmqOUREhZ
TnS5XKKnqummNv5KBrMYylLOJKYk4pFHkBFA45aG8no3Q1VI7q6ciXDIgzP0VO1x
9c5rGpYByS9xkfPE7t66epG3fMjDBiqTiPLd9mOZ+Gn5QrHU00S52FOy8P2tVYIy
RVLayNYZeyzyiZj5FG4G+lI8kp4t6bmW9bZgKn2zXNs1BtdWjlD3P5zGuhx0Y/yF
8BRhjjmYml84+dGZdyvuVcDWaSWNbGZ1/GA/wz2g+w6kpa1AoFDiYFDjSdTSNHum
mqsacTuyoFBLsOB8aE9PsgCr7CwfY4pbDl1eTQIDAQABAoIBAG13qe5SLW8qsn6E
2jMPt2Zx1HMvxwAuFYJb2Ei5RzkBvfPCjPmfYzyxRXmX3WDSIlflPHMbukfsixFN
JFui6LaQNKFNz3ZKEwkf9bLEBJjF6lkV5WwJWx0WFh0n6D2KoHhpmR8iDs4kj9zh
jdj4jeJZO8syFGe/k2LDlQhgNMRu36AJhRutZgAN3Q65uYWEXs7SbVxzr6etIMe5
sJ1fx9EN6A8y0HRqy8c+ljEwAL5Q383EdApHhfbayuK8pZzPlDzZ+cRDG3ILQUZK
c6bp2PgHWtkVhq98BPkPNq+VAG/XrutbcmZD54dMXgf7WakMGlDSNFRtKpstlP6A
yXq0kMECgYEA4a9XP/a8MZTFiNrO6fkJsT8qP7mxTMFa9Nwksnkg43ohO34oQkh+
1SaHjdDPYxHkcX2QMQQIKJU8u6U1BRDltxT9rPvR3ZlIx+y00x5tLrfNSinU1nGz
R70LYAYdc5Ye93A6f/7mqjUAXwcAB81y/0f4uP71O6LHrGbkwaGpabkCgYEAwEio
UgdwUCfDG8uNLUL9XjHODeLBjTZ0kRVCxWayXoYzyfhzJZtmYWHqyvporRaf/ZXW
sjQFDykboROnaYGNHdEp+Ay7i9c83is3lSPRHv5+B0i/w9ddNQTgvJYDk958uXem
Q9zNiYMjHGgtIrOxBarzaqjsA7tQxvgDx7zf0zUCgYAqX7KhFuGU6ZsBLBwngBPa
zMJQ/ruUbsV2LhNR0z5il56/vdsvPs9ZlAdlkCwwLL7YtDuriFdDz2l8zfMbhWWs
L2vF2+42jj5FE2OMNC1J1UbdQudscCK6OHt3Rw6mkiw0R0UknSaQFK2CKh1OWbva
xJelnHFNBi45Z4RR+tmFOQKBgDBelqj74g7n0bbeP4dRQLc/RBxOHG5PcodEl+Vc
biZFECYQb7bYHqsEnLGuyEIyXNDHrphpaZRkvOSKMyThSARmJ26UlWEaJd+lc3f6
6JIpZr6iWEsFlBbQQVBvVDsQTsPBC3wqwTGEYYK12hTOqwtH86+zCpvttOY4YYsP
Qia5AoGBAKjlJU2tsU/cBal2NedoYYbGeIux3qYNZ8vPXX1ptbtZxPjATbLI+NPd
VoR53fFXpB00xCNAyW6jnRvuY9itNSYVljEdrbQyl+hVshuM34WfIpZbFzLSe9HE
P+H8ji+ShlSRVJNs7phLZsadvm5iqkWxtE2HwAwBLHSNEBVmb/cb
-----END RSA PRIVATE KEY-----',

//The current_rsa_timestamp and the last_rsa_timestamp store the Unix-time time(), when the current/last private key was generated. This is important, when the private key is renewed every day or so. The last private key has to be stored here, so that the server still has the right key present for browsers, which dont have the changed key yet. Supports some kind of perfect forward secrecy
'current_rsa_timestamp' => 1410876214,

'last_rsa_privatekey' => '-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA1GxR7Pm945TrH5/+trNmSqVqzwMkxWfkG0xG9g6997YTM+Hp
QR4uUYo23o0IiplStYfKT9zx2H10LaEBp+z7pmrP6MXUIJdewuF7cA1D2MZoQQFH
//78EnwXFze88k6t+KEbzVXHWTUW0Q1JofwBFZ/TsqPGI+t0w50VC0KVMXJnqI4i
eh2Tz2ZpEXj3m5ghx1VKpp2horOaYjwnnDnAHnZ06sYi6zni9QC/XNmnYkfkJb0m
wD+GwOan9ANkxPGCz9cX2ZWls/ClSXNhQle/pREBU2/p4KGlpFQ7lC0RLI3K+DlH
Qy94PbgauAUbgC+YcPCN1KczyBkOg49bJjrK1QIDAQABAoIBAHObO/7/cBOykT/V
4FboTcxkODvPlyyEPQWKPrhdD5AHnG3JDhvtZAHmebQnBzX++Z9n9nf+Y/SRWjAX
BwKwG8jXKq2hNLBEEUN4WaiC36DTYhu2qcutptwcgqiVIhSxM0czzyCyBVsMZI2D
cMZikuiE4j6/mO8ljpeDHtfQ9cdBYIObu4RAzN7tYV/iae06Upa7pTL0Z0gD7W67
hbqzcm4ugWKrSUNGDafrJGUR2Qbjjp7xrZ9z+hp4IP9De1XiFQnvxnY6+GeDQa1k
KhbbWB1PhpqrPMLjZtwxzezq3aj9WyJtQlamrtN1u/bTMjvLBhBq+EDgtvYOSh7z
UhlLj4UCgYEA/DKtUD6ixtb2BoJd/CQEZ63Ay5mcrWgSUx7G0Y9W7Nj3U0BbASX7
2gqpB0kXMkiCJTO/ec70VnTBVUrUauZl03P2vjxL79yBa0ZC27hwaxgwe0Elds61
h6KlKjDXoCEjeiiuqneQlSEjvQvCxQpprtWR34bTpDPE9Hu417sEvY8CgYEA16Aj
OCrXB9tNwFpLe2bHqFIjGXLtV+g86YGYJMoeoJYsFW8ZSY78PTmppeNLnJQuOaJI
WKJ5Jj7op8Eo/FfKzfTaER8gOESFRkgF3pUnpBKEfo/4VB6lmZz+Ok1B23HnGlPt
e/krPzoIMYNLxL/oXZXDk9Ac2CVGwedMlTqbh1sCgYEAsNTXsOw6NjGDUA0Y2TJn
5EpwZFHRCcVvE9kAju9yg5+dy0HUjXmUnc3btsAJA7jTiEJAf6gcqoIzDRrq1gm2
XA1zdO/STtzN4enh9y3bpTvQwptrKWLG5dOk+3BDwIN73KupzN0JA4e5B1S3vHEQ
qQYWwiRHQVsLPmGBucHoEQECgYAVaK32hrJg8lJO9egmsXbDbJxVi4arQsDBgn+D
r5nI4gAwhJ5jIlJDFfWVJfM88a2BRW6fdkpHFNnuxgv2uhTFzDjWmFuPmqYM61vB
1NdhwADtvAew+nYAwYiwazlNu4pxn8GlnIDBv1ZO7DVarJ86o4MOqwwiHdlfqUJ+
UppcnwKBgQDsB8nbZGlxMBlcNVve0yPSeAMmJK5P9LGbYnUSaM1JyklxA7VEQuL/
+gnKxJiQguoSME1cBpn6VnKG5muPXmoRKa5QxbF1m+zmZLz5mkoiqshnaG6v1IYc
O/g/toMJXlRGvbSMw7P8hkwQ/hI+6J31HQPFSDDJRUGYGTwALRsvGA==
-----END RSA PRIVATE KEY-----',

'last_rsa_timestamp' => 1410875909);

?>